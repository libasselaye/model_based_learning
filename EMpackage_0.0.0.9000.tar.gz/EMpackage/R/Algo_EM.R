#' @import DirichletReg
#' @import mvtnorm
#' @import matlib
#' @import stats
#' @import utils
#' @import mclust

logsumexp <- function(X){
  c = max(X)
  return(c + log(sum(exp(X - c))))
}



#Le calcul de la Log-Vraisemblance

Log_likelihood <- function(X,K,vector_pk,vector_uk,vector_sigk){

  val <- 0

  for(i in 1:nrow(X)){
    sum <- 0
    for(k in 1:K){
      sum <- sum + vector_pk[k] * dmvnorm(X[i,], vector_uk[k,], vector_sigk[,,k])
    }
    sum <- logsumexp(log(sum))
    val = val + sum
  }

  return(val)
}


#Initialisation  Aleatoire


initialisation <- function(X,K){


  vector_pk <- rdirichlet(1,alpha=rep(1,K))

  vector_uk <- matrix(0,nrow = K,ncol = ncol(X))

  vector_sigk <- array(NA,dim=c(ncol(X),ncol(X),K))

  for(i in 1:ncol(X)){
    vector_uk[,i] <- runif(K, min(X[,i]), max(X[,i]))
  }

  for(k in 1:K){
    for(i in 1:(ncol(X))){
      for(j in (i):ncol(X)){

        vector_sigk[i,j,k] <- runif(1, 0, ((max(X[,i])-min(X[,i]))^2)/4)
        vector_sigk[j,i,k] <- vector_sigk[i,j,k]
      }
    }
  }


  init_param_list <- list("vector_pk"=vector_pk,"vector_uk"=vector_uk,"vector_sigk"=vector_sigk)
  return(init_param_list)
}


#L'initiatisation par Kmeans de l'algo EM


initialisation_Kmeans <- function(X,K){

  #Une seed est mise pour la reproductibilit? des resultats
  set.seed(2022)
  res.km <- kmeans(scale(X), K, nstart = 50,iter.max = 100)

  #Les clusters attribues par Kmeans sont recuperes
  cluster <- factor(res.km$cluster)

  #Puis les proportions, les moyennes et les matrices de covariances sont calcul?es a partir des resultats
  #precedents

  n=nrow(X)
  p=ncol(X)
  z=cluster


  prop=rep(NA,K)
  mu=matrix(NA,K,p)
  sigma=array(NA,dim=c(p,p,K))
  for (k in 1:K){
    prop[k]=mean(z==levels(z)[k])
    mu[k,]=colMeans(X[which(z==levels(z)[k]),])
    sigma[,,k]=var(X[which(z==levels(z)[k]),])
  }
  return(list(vector_pk=prop,vector_uk=mu,vector_sigk=sigma,K=K))
}




# L'Etape E de l'EM

Etape_E <- function(X,K,vector_uk,vector_sigk,vector_pk){


  mat_tk <- matrix(0,nrow = nrow(X),ncol = K)

  for(j in 1:K){
    mat_tk[,j] <- vector_pk[j] * dmvnorm(X, vector_uk[j,], sigma = vector_sigk[,,j], log=FALSE)
  }

  mat_tk <- mat_tk/rowSums(mat_tk)

  #La matrice contenant les tk de chaque x_i a l'etape q est renvoy?e
  return(mat_tk)
}




#L'etape M de l'Algo EM dans le cas classique(VVV)


Etape_M_VVV <- function(mat_tk,X,K){

  n_k <- colSums(mat_tk)

  vector_pk <- c()

  vector_uk <- matrix(0,nrow = K,ncol = ncol(X))

  vector_sigk <- array(0,dim=c(ncol(X),ncol(X),K))

  vector_pk <- c(vector_pk,n_k/nrow(X))

  for (k in 1:K){

    vector_uk[k,] = (t(X) %*% mat_tk[,k]) / n_k[k]

  }

  for (k in 1:K){
    for (i in 1:nrow(X)){
      vector_sigk[,,k] = vector_sigk[,,k] + mat_tk[i,k] * (X[i,]-vector_uk[k,])%*%t(X[i,]-vector_uk[k,])
    }
    vector_sigk[,,k] =  vector_sigk[,,k]/n_k[k]
  }

  # Apres Maximisation , on retourne les nouvelles proportions, moyennes et  matrices de covariances

  param_list <- list("vector_pk"=vector_pk,"vector_uk"=vector_uk,"vector_sigk"=vector_sigk)
  return(param_list)
}






#L'etape M de l'Algo EM (EEE)


Etape_M_EEE <- function(mat_tk,X,K){

  # En se basant sur l'article Regularized Gaussian Discriminant Analysis Through Eigenvalue Decomposition
  n_k <- colSums(mat_tk)

  vector_pk <- c()

  vector_uk <- matrix(0,nrow = K,ncol = ncol(X))

  vector_Wk <- array(0,dim=c(ncol(X),ncol(X),K))

  W <- matrix(0,nrow = ncol(X),ncol = ncol(X))

  vector_sigk <- array(0,dim=c(ncol(X),ncol(X),K))

  vector_pk <- c(vector_pk,n_k/nrow(X))

  for (k in 1:K){

    vector_uk[k,] = (t(X) %*% mat_tk[,k]) / n_k[k]

  }

  #Les details pour obtenir la matrice de covariance se trouve dans l'article cit? ci-dessus
  for (k in 1:K){
    for (i in 1:nrow(X)){
      vector_Wk[,,k] = vector_Wk[,,k] + mat_tk[i,k] * (X[i,]-vector_uk[k,])%*%t(X[i,]-vector_uk[k,])
    }
  }

  for (k in 1:K){

    W <- W + vector_Wk[,,k]

  }

  W <- W/nrow(X)

  for (k in 1:K){

    vector_sigk[,,k] <- W

  }

  # Apres Maximisation , on retourne les nouvelles proportions, moyennes et  matrices de covariances

  param_list <- list("vector_pk"=vector_pk,"vector_uk"=vector_uk,"vector_sigk"=vector_sigk)
  return(param_list)
}




Etape_M_VII <- function(mat_tk,X,K){


  # En se basant sur l'article Regularized Gaussian Discriminant Analysis Through Eigenvalue Decomposition
  n_k <- colSums(mat_tk)

  vector_pk <- c()

  vector_uk <- matrix(0,nrow = K,ncol = ncol(X))

  vector_Wk <- array(0,dim=c(ncol(X),ncol(X),K))

  Lambda_k <- c()

  vector_sigk <- array(0,dim=c(ncol(X),ncol(X),K))

  vector_pk <- c(vector_pk,n_k/nrow(X))

  for (k in 1:K){

    vector_uk[k,] = (t(X) %*% mat_tk[,k]) / n_k[k]

  }

  for (k in 1:K){
    for (i in 1:nrow(X)){
      vector_Wk[,,k] = vector_Wk[,,k] + mat_tk[i,k] * (X[i,]-vector_uk[k,])%*%t(X[i,]-vector_uk[k,])
    }
  }

  for (k in 1:K){

    Lambda_k <- c(Lambda_k,(sum(diag(vector_Wk[,,k])))/ (n_k[k]*ncol(X)))

  }

  for (k in 1:K){

    vector_sigk[,,k] <- Lambda_k[k]*diag(ncol(X))

  }

  #Les details pour obtenir la matrice de covariance se trouve dans l'article cit? ci-dessus


  # Apres Maximisation , on retourne les nouvelles proportions, moyennes et  matrices de covariances

  param_list <- list("vector_pk"=vector_pk,"vector_uk"=vector_uk,"vector_sigk"=vector_sigk)
  return(param_list)
}




# une succession des deux precedentes fonctions permet  d'obtenir l'algo d'expectation-Maximisation
#'  une succession des deux precedentes fonctions permet  d'obtenir l'algo d'expectation-Maximisation
#'
#' @param X Un vecteur numerique
#' @param K Le nombre de composante
#' @param nb Le nombre d'iteration max
#' @param type Le nom du modele que l'on veut utilisé
#' @param vis_it Affiche ou non les iterations
#'
#' @return la fonction retourne les parametres et les membres de cluster
#' @export
#'
#' @examples
Algo_EM <- function(X,K,nb=500,type="VVV",vis_it=TRUE){

  X <- as.matrix(X)

  #Initialisation par Kmeans
  init_params <- initialisation_Kmeans(X,K)
  params <- 0
  Tab_LL <- c()

  i <- 1

  convergence = FALSE

  ll <- 0


  while(i < nb & convergence == FALSE){

    if(vis_it){
      cat(paste("Iterations numero : ",format(i), "\n", sep = ""))
    }

    ll_old <- ll

    if(i == 1){

      params <- init_params

    }

    #Calcul de la matrice tk
    mat_tk <- Etape_E(X,K,params$vector_uk,
                      params$vector_sigk,params$vector_pk)


    # Calcul des parametres a l'etape q avec les differents modeles

    if(type=="VVV"){
      params <- Etape_M_VVV(mat_tk,X,K)
    }
    if(type=="EEE"){
      params <- Etape_M_EEE(mat_tk,X,K)
    }
    if(type=="VII"){
      params <- Etape_M_VII(mat_tk,X,K)
    }
    # On calcul la Log-Likelihood et on le stocke pour verifier qu'il augmente

    ll <- Log_likelihood(X,K,params$vector_pk,params$vector_uk,
                         params$vector_sigk)

    Tab_LL <- c(Tab_LL,ll)

    i <- i + 1

    #Definition du critere de Convergence
    convergence = min(abs(ll - ll_old)) <= 0.0001

    #On test si la la convergence existe(donc a pu etre calcul?)
    if(is.na(convergence)){

      convergence = FALSE
    }
    #Meesage de FIN de process
    if(convergence){
      cat(paste("CONVERGENCE ATTEINT ", "\n", sep = ""))
    }
  }

  # Pour l'attribution des individus dans un cluster on cherche le cluster ou l'individu a le plus de chance de se trouver
  # a l'etape n

  pos_max <- apply(mat_tk, 1, which.max)

  #A la toute fin on retourne tous les parametres calcul?s

  return(list(proba=params$vector_pk,mu=params$vector_uk,covar=params$vector_sigk,mat_tk=mat_tk,cluster=pos_max,Tab_LL=Tab_LL))
}
