
Spectral_decomp <- function(vector_sigk){

  dimension <- dim(vector_sigk)


  Tab_lambdak <- c()

  vector_Dk <- array(NA,dim=c(dimension[1],dimension[2],dimension[3]))

  vector_Ak <- matrix(0,nrow = dimension[3],ncol = dimension[1])

  for(k in 1:dimension[3]){

    ev <- eigen(vector_sigk[,,k])

    Tab_lambdak <- c(Tab_lambdak,max(abs(ev$values)))

    vector_Ak[k,] <- ev$values

    vector_Dk[,,k] <- ev$vectors

  }

  return(list(lambda_k=Tab_lambdak,A_k = vector_Ak,D_k = vector_Dk))
}



#Critere BIC a maximiser

Critere_BIC <- function(LL,N,K){

  BIC <- 2*LL - K*log(N)

  return(BIC)
}



#Code de prediction de la classe d'appartenance des individus Test


predict.gmmclassif = function (X,K,vector_pk,vector_uk,vector_sigk){
  tik=matrix(NA,nrow(X),K)
  for (k in 1:K){
    tik[,k] = vector_pk[k] * dmvnorm(X,vector_uk[k,],vector_sigk[,,k])
  }
  tik=tik/rowSums(tik)
  z=max.col(tik)
  return(list(z=z,tik=tik))
}




#Algo de Classif


#' Algo de Classif
#'
#' @param X.Train Vecteur de Features Train
#' @param Class.Train Vecteur de variable cible
#' @param X.Test Vecteur de Features Test
#' @param NbrMaxComp Nombre Maximum de Composants par classe
#'
#' @return La fonction retourne les predictions , les infos des modeles et les parametres estimés
#' @export
#'
#' @examples
Classif_MM <- function(X.Train,Class.Train,X.Test,NbrMaxComp){

  #Nous recuperons le nombre de classe
  #Nous instantions les Tableaux de BIC et de Log Vraisemblance

  K <- length(unique(Class.Train))

  Tab_LL_VII <- c()
  Tab_LL_EEE <- c()
  Tab_LL_VVV <- c()
  Tab_BIC_VII <- c()
  Tab_BIC_EEE <- c()
  Tab_BIC_VVV <- c()

  array_BIC_class <- array(0,dim=c(3,NbrMaxComp,K))

  result_bic_class <- c()


  #Si le nombre de composant max est de 1 ,
  #Alors un EM classique est realis?

  if(NbrMaxComp == 1){
    pred_final <- c()
    run_EM <- Algo_EM(X.Train,K,vis_it = FALSE)

    #Avec le Tableau de contigence , on associe une chiffre a un label
    #Pour la prediction finale
    table_cont <- table(run_EM$cluster,Class.Train)
    tabpred <- colnames(table_cont)[max.col(table_cont, ties.method = "first")]

    prediction <- predict.gmmclassif(X.Test,K,run_EM$proba,run_EM$mu,run_EM$covar)

    for(i in 1:length(prediction$z)){
      pred_final <- c(pred_final,tabpred[prediction$z[i]])
    }
    return(list(prediction=pred_final,modele="XXX",NbrComp=1,params=run_EM))
  }

  #Si le nombre de composante par classe est >= 1 alors

  #Nous recuperons le noms de classes
  class <- levels(Class.Train)

  full_data <- as.data.frame(cbind(X.Train,Class.Train))

  #Nous separons les classes par label
  split_by_class <- split(full_data,f=Class.Train)


  # La LL et BIC sont calcul?es
  for(i in 1:length(class)){

    data <- split_by_class[[class[i]]]
    data <- data[,-ncol(data)]


    Tab_LL_VII <- c()
    Tab_LL_EEE <- c()
    Tab_LL_VVV <- c()
    Tab_BIC_VII <- c()
    Tab_BIC_EEE <- c()
    Tab_BIC_VVV <- c()

    for(k in 1:NbrMaxComp){


      Tab_LL_VII <- c(Tab_LL_VII,tail(Algo_EM(data,k,type="VII",vis_it = FALSE)$Tab_LL,1))
      Tab_LL_EEE <- c(Tab_LL_EEE,tail(Algo_EM(data,k,type="EEE",vis_it = FALSE)$Tab_LL,1))
      Tab_LL_VVV <- c(Tab_LL_VVV,tail(Algo_EM(data,k,type="VVV",vis_it = FALSE)$Tab_LL,1))

    }

    for(k in 1:NbrMaxComp){


      Tab_BIC_VII <- c(Tab_BIC_VII,Critere_BIC(Tab_LL_VII[k],nrow(data),(k-1 + k*ncol(data) + ncol(data))))
      Tab_BIC_EEE <- c(Tab_BIC_EEE,Critere_BIC(Tab_LL_EEE[k],nrow(data),(k-1 + k*ncol(data) + ncol(data)*(ncol(data)+1)/2)))
      Tab_BIC_VVV <- c(Tab_BIC_VVV,Critere_BIC(Tab_LL_VVV[k],nrow(data),(k-1 + k*ncol(data) + k*ncol(data)*(ncol(data)+1)/2)))

    }
    array_BIC_class[1,,i] <- Tab_BIC_VII
    array_BIC_class[2,,i] <- Tab_BIC_EEE
    array_BIC_class[3,,i] <- Tab_BIC_VVV
  }

  infos_model <- c()
  K_mod_fin <- 0

  #Nous recuperons des infos sur les modeles maximisants le critere BIC
  for(i in 1:length(class)){

    modele <- ""

    x <- array_BIC_class[,,i]
    pos_max_val <- arrayInd(which.max(x), dim(x))

    K_mod_fin <- K_mod_fin + pos_max_val[2]

    if(pos_max_val[1]== 1){

      modele <- "VII"
    }

    if(pos_max_val[1]== 2){

      modele <- "EEE"
    }

    if(pos_max_val[1]== 3){

      modele <- "VVV"
    }

    infos_model <- c(infos_model,list(list(classe=class[i],modele_Chs=modele,Nbr_Comp=pos_max_val[2],BIC=x[pos_max_val[1],pos_max_val[2]])))

  }

  Tab_params_class <- c()

  #Nous recuperons les probas ,mu et sigk des modeles selectionn?s
  for(i in 1:length(class)){

    data <- split_by_class[[class[i]]]
    data <- data[,-ncol(data)]

    Tab_params_class <- c(Tab_params_class,list(Algo_EM(data,infos_model[[i]]$Nbr_Comp,type=infos_model[[i]]$modele_Chs,vis_it = FALSE)))

  }

  vector_pkf <- c()

  vector_ukf <- matrix(0,nrow = K_mod_fin,ncol = ncol(X.Train))

  vector_sigkf <- array(0,dim=c(ncol(X.Train),ncol(X.Train),K_mod_fin))

  Nbr_elem_class <- c()

  #Le modele definitif utilis? pour la prediction est cr?e

  for(i in 1:length(class)){

    data <- split_by_class[[class[i]]]

    Nbr_elem_class <- c(Nbr_elem_class,nrow(data))
  }

  j <- 1

  #Un dictionnaire contenant une association label -> num cluster est cr?e

  dict_ind_class <-matrix(0,nrow = K_mod_fin,ncol = 1)

  for(k in 1:length(class)){

    proba <- Tab_params_class[[k]]$proba
    mu <- Tab_params_class[[k]]$mu
    covar <- Tab_params_class[[k]]$covar

    for(i in 1:length(proba)){

      vector_pkf <- c(vector_pkf,(Nbr_elem_class[k]*proba[i])/nrow(X.Train))
      vector_ukf[j,] <- mu[i,]
      vector_sigkf[,,j] <- covar[,,i]
      dict_ind_class[j] <- class[k]
      j <- j + 1

    }

  }
  #Nous realisons la prediction et renvoyons tous les parametres
  pred_final <- c()
  result_prediction <- predict.gmmclassif(X.Test,K_mod_fin,vector_pkf,vector_ukf,vector_sigkf)
  for(i in 1:length(result_prediction$z)){
    pred_final <- c(pred_final,dict_ind_class[result_prediction$z[i]])
  }
  return(list(prediction=pred_final,infos_modeles=infos_model,params=Tab_params_class))
}
