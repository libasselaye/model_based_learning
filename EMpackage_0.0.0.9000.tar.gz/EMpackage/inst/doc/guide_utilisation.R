## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(EMpackage)

## -----------------------------------------------------------------------------

#Chargement de IRIS

set.seed(2)
tmp=sample(1:150,50)


#Les features

X.train <- iris[-tmp,-5]
X.test <- iris[tmp,-5]
X <- iris[,1:4]

#La variable cible

Class.train <- iris[-tmp,5]
Class.test <- iris[tmp,5]
Y <- iris[,5]

#Testons l'algorithme d'Expectation Maximisation

# Il existe un mode verbose en activant vis_it = TRUE

# nb permet de fixer le nombre maximal d'iteration

# type est le nom du modele utilisé : VVV , EEE , VII

# Nous choisissons K, le nombre de composants/clusters = 3

mytest <- Algo_EM(X,3,nb=100,type="VVV",vis_it = TRUE)


## -----------------------------------------------------------------------------
table(mytest$cluster,Y)

## -----------------------------------------------------------------------------
plot(mytest$Tab_LL)

## -----------------------------------------------------------------------------
library(mclust)
 
test <- mclust::Mclust(X,3)

table(test$classification,Y)

## -----------------------------------------------------------------------------
mytest <- Algo_EM(X,15,vis_it = FALSE)

table(mytest$cluster,Y)

plot(mytest$Tab_LL)

## -----------------------------------------------------------------------------
mytest <- Algo_EM(X,3,vis_it = FALSE)

clusters =   mytest$cluster

proba = mytest$proba

mu = mytest$mu

sigma = mytest$covar

Log_L = mytest$Tab_LL

mat_tk = mytest$mat_tk

print(clusters)


## -----------------------------------------------------------------------------
mytest2 <- Classif_MM(X.train,Class.train,X.test,3)

## -----------------------------------------------------------------------------
table(mytest2$prediction,Class.test)

## -----------------------------------------------------------------------------
mytest2$infos_modeles

## -----------------------------------------------------------------------------
mytest2$params

